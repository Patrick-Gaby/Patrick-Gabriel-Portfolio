function toggleBar(toggleTransition) {
  toggleTransition.classList.toggle("toggleTransitionAction");
  document.getElementById("sideNavigationContentWrapper").classList.toggle("toggleSlidePannel");
  document.getElementById("contentContainerWrapper").classList.toggle("toggleMoveContent");
}

function toggleDarkmode(darkMode) {
  darkMode.classList.toggle("lightMode");
  document.getElementById("switchIcon").classList.toggle("lightMode");
  document.getElementById("switchCoverIcon").classList.toggle("lightMode");
  document.getElementById("toggleIcon").classList.toggle("lightMode");
}
